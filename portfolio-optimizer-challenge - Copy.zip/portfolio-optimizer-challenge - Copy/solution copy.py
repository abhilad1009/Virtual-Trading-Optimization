import datetime
import typing as t

import numpy as np
import numpy.typing as npt
import pandas as pd
import scipy as sp  # type: ignore[import-untyped]
import tqdm
import matplotlib.pyplot as plt

from joblib import Parallel, delayed

import argparse

FloatArray = npt.NDArray[np.float_]

RISK_TOLERANCE = 500
DAILY_VOLUME_LIMIT = 100


def compute_expected_spread(price_df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute the expected spread for each node and hour for the operating day, by taking the mean of observed
    spread values available as of 24 hours prior to the beginning of the operating day.

    :param price_df: historical price data [operating_day, hour_beginning, node, da_price, rt_price]
    :return: data frame of expected spread values [operating_day, hour_beginning, node, expected_dart_spread]
    """
    price_df["node_dart"] = price_df['da_price'] - price_df['rt_price']
    df_concat_list = []
    for node in price_df.node.unique():
        node_df = price_df[price_df['node'] == node].copy()
        node_df['expected_dart_spread'] = node_df['node_dart'].rolling(24,min_periods=1,closed='left').mean().fillna(0)
        df_concat_list.append(node_df.copy())
    
    merged_df = pd.concat(df_concat_list)
    merged_df.sort_index(inplace=True)

    # price_df['expected_dart_spread'] = price_df["node_dart"].rolling(8*24,closed='left').mean()
    # x = price_df.rolling("1D",on='operating_day',closed='left').mean()
    # print(x)
    # print(merged_df)

    return merged_df[['operating_day', 'hour_beginning', 'node', 'expected_dart_spread']]


def compute_spread_variance(price_df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute the estimated spread variance for each node and hour for the operating day, by taking the sample variance
    of observed spread values available as of 24 hours prior to the beginning of the operating day.

    :param price_df: historical price data [operating_day, hour_beginning, node, da_price, rt_price]
    :return: data frame of estimated spread variance values [operating_day, hour_beginning, node, dart_spread_var]
    """
    price_df["node_dart"] = price_df['da_price'] - price_df['rt_price']
    df_concat_list = []
    for node in price_df.node.unique():
        node_df = price_df[price_df['node'] == node].copy()
        node_df['dart_spread_var'] = node_df['node_dart'].rolling(24,min_periods=1,closed='left').var().fillna(0)
        df_concat_list.append(node_df.copy())
    
    merged_df = pd.concat(df_concat_list)
    merged_df.sort_index(inplace=True)

    # price_df['dart_spread_var'] = price_df["node_dart"].rolling(8*24,closed='left').mean()
    # x = price_df.rolling("1D",on='operating_day',closed='left').mean()
    # print(x)
    # print(merged_df)

    return merged_df[['operating_day', 'hour_beginning', 'node', 'dart_spread_var']]



def get_daily_expected_spread_vectors(expected_spread_df: pd.DataFrame) -> pd.DataFrame:
    """
    Transform the expected spread data frame into a data frame with one row per operating day, where the index is
    the operating day and the elements of each row are the expected spread values for all node and hour combinations
    on that day.

    :param expected_spread_df: data frame of expected spread values
        [operating_day, hour_beginning, node, expected_dart_spread]
    :return: data frame of expected spread vectors with operating day as index
    """
    spread_vector_df = pd.pivot_table(expected_spread_df,index=['operating_day'],columns=expected_spread_df.groupby(['operating_day']).cumcount().add(1),values=['expected_dart_spread'],aggfunc='sum')
    cols = [r['node']+"_"+str(r['hour_beginning']) for idx,r in expected_spread_df[:8*24].iterrows()]
    spread_vector_df.columns = cols
    # print(spread_vector_df) 
    return spread_vector_df


def get_daily_spread_variance_vectors(spread_var_df: pd.DataFrame) -> pd.DataFrame:
    """
    Transform the spread variance data frame into a data frame with one row per operating day, where the index is
    the operating day and the elements of each row are the estimated spread variance values for all node and hour
    combinations on that day (i.e. the diagonal entries of the covariance matrix).

    :param spread_var_df: data frame of expected spread values
        [operating_day, hour_beginning, node, dart_spread_var]
    :return: data frame of expected spread vectors with operating day as index
    """
    spread_var_vector_df = pd.pivot_table(spread_var_df,index=['operating_day'],columns=spread_var_df.groupby(['operating_day']).cumcount().add(1),values=['dart_spread_var'],aggfunc='sum')
    # print(spread_var_vector_df) 
    cols = [r['node']+"_"+str(r['hour_beginning']) for idx,r in spread_var_df[:8*24].iterrows()]
    spread_var_vector_df.columns = cols

    return spread_var_vector_df


def portfolio_objective_fn(
    bid_mw: FloatArray,
    expected_spread: FloatArray,
    spread_variance: FloatArray,
    risk_tol: int
) -> float:
    """
    The objective function to minimize in the portfolio optimizer. This should also use the RISK_TOLERANCE constant
    defined above.

    :param bid_mw: array containing the bid quantities (in MW) for the daily portfolio
    :param expected_spread: array containing the expected spread values for the day
    :param spread_variance: array containing the estimated spread variance values for the day (i.e. the diagonal
        entries of the covariance matrix)
    :return: objective function value to minimize
    """
    covariance_matrix = np.diag(spread_variance)

    # print(bid_mw.shape)
    # print(covariance_matrix.shape)
    # print(expected_spread.shape)
    portfolio_objective_fn = np.dot(np.dot(bid_mw, covariance_matrix),bid_mw)  - risk_tol * np.dot(expected_spread ,bid_mw)
    
    # print(portfolio_objective_fn)
    return portfolio_objective_fn


def mw_constraint_fn(bid_mw: FloatArray, max_total_mw: float) -> float:
    """
    The constraint function which must take a non-negative value if and only if the constraint is satisfied.

    :param bid_mw: array containing the bid quantities (in MW) for the daily portfolio
    :param max_total_mw: the maximum number of total MW that can be traded in a day
    :return: constraint function value which must be non-negative iff the constraint is satisfied
    """
    return max_total_mw - np.sum(bid_mw)



def get_bids_from_daily_portfolios(portfolio_df: pd.DataFrame) -> pd.DataFrame:
    """
    Transform a data frame of daily portfolios to a data frame of bids. Also removes any bids smaller than 0.1 MW.

    :param portfolio_df: data frame of daily bid quantities with operating day as the index
    :return: data frame of bids [operating_day, hour_beginning, node, bid_type, bid_mw]
    """
    nodes, opening_hours = zip(*(s.split("_") for s in portfolio_df.columns))
    bids = portfolio_df.to_numpy().flatten().tolist()
    node_repeatition = int(len(bids)/len(nodes))

    bid_df = pd.DataFrame({
        "operating_day":np.repeat(portfolio_df.index.date,8*24).tolist(),
        "hour_beginning":opening_hours*node_repeatition,
        "node":nodes*node_repeatition,
        "bid_mw":bids
    })

    bid_df['bid_type'] = np.where(bid_df['bid_mw']>=0,"INC","DEC")
    bid_df.bid_mw[(bid_df['bid_mw'].lt(0.1)) & (bid_df['bid_mw'].gt(-0.1))] = 0

    bid_df['operating_day'] = bid_df['operating_day'].astype('datetime64')
    bid_df['hour_beginning'] = bid_df['hour_beginning'].astype('int')

    # print(bid_df)

    return bid_df


def compute_total_pnl(price_df: pd.DataFrame, bid_df: pd.DataFrame) -> float:
    """
    Compute the total PnL over all operating days in the bid data frame

    :param price_df: historical price data [operating_day, hour_beginning, node, da_price, rt_price]
    :param bid_df: data frame of bids [operating_day, hour_beginning, node, bid_type, bid_mw]
    :return: the total PnL
    """
    merged_df = pd.merge(price_df,bid_df,on=['operating_day','hour_beginning','node'])
    merged_df['pnl'] = merged_df['node_dart']*merged_df['bid_mw']
    # print(merged_df)
    return merged_df['pnl'].sum()

def win_loss_rate(price_df: pd.DataFrame, bid_df: pd.DataFrame) -> float:

    merged_df = pd.merge(price_df,bid_df,on=['operating_day','hour_beginning','node'])
    merged_df['pnl'] = merged_df['node_dart']*merged_df['bid_mw']
    # print(merged_df)
    wins = len(merged_df[merged_df['pnl']>=0])
    losses = len(merged_df)-wins
    return wins/losses

def profit_factor(price_df: pd.DataFrame, bid_df: pd.DataFrame) -> float:

    merged_df = pd.merge(price_df,bid_df,on=['operating_day','hour_beginning','node'])
    merged_df['pnl'] = merged_df['node_dart']*merged_df['bid_mw']
    # print(merged_df)
    gross_profit = merged_df[merged_df['pnl']>=0]['pnl'].sum()
    gross_loss = abs(merged_df[merged_df['pnl']<0]['pnl'].sum())
    return gross_profit/gross_loss

def sharpe_ratio(price_df: pd.DataFrame, bid_df: pd.DataFrame) -> float:



    merged_df = pd.merge(price_df,bid_df,on=['operating_day','hour_beginning','node'])
    merged_df['pnl'] = merged_df['node_dart']*merged_df['bid_mw']
    # print(merged_df)
    daily_returns = merged_df.groupby("operating_day").sum().copy()
    risk_free_rate = (1.052**(1/len(daily_returns))) - 1
    daily_returns['return_rate'] =  daily_returns['pnl'].pct_change().fillna(0)
    # print(daily_returns)
    # print(daily_returns['return_rate'].mean(),risk_free_rate,daily_returns['return_rate'].std())
    sr = (daily_returns['return_rate'].mean() - risk_free_rate)/daily_returns['return_rate'].std()

    return sr

def plot_drawdown(price_df: pd.DataFrame, bid_df: pd.DataFrame) -> float:


    merged_df = pd.merge(price_df,bid_df,on=['operating_day','hour_beginning','node'])
    merged_df['pnl'] = merged_df['node_dart']*merged_df['bid_mw']
    # print(merged_df)
    daily_returns = merged_df.groupby("operating_day").sum().copy()
    daily_returns['return_rate'] =  daily_returns['pnl'].pct_change().fillna(0)
    cummulative_prod = 1000*(1+daily_returns['return_rate']).cumprod()
    previous_peaks = cummulative_prod.cummax()
    drawdown = (cummulative_prod-previous_peaks)/previous_peaks
    drawdown.plot()
    plt.show()

def plot_cummulative_returns(price_df: pd.DataFrame, bid_df: pd.DataFrame) -> float:


    merged_df = pd.merge(price_df,bid_df,on=['operating_day','hour_beginning','node'])
    merged_df['pnl'] = merged_df['node_dart']*merged_df['bid_mw']
    # print(merged_df)
    daily_returns = merged_df.groupby("operating_day").sum().copy().fillna(0)
    t = 0
    cummulative_pnl= []
    for pnl in daily_returns['pnl'].values:
        t+=pnl
        cummulative_pnl.append(t)
    plt.plot(daily_returns.index.values,cummulative_pnl)
    plt.show()

def generate_daily_bids(
    price_df: pd.DataFrame,
    risk_tol: int,
    first_operating_day: t.Union[str, datetime.date],
    last_operating_day: t.Union[str, datetime.date],
) -> pd.DataFrame:
    """
    Generate bids for the date range, computing the expected DART spreads and estimated variances from
    the price data and limiting each daily portfolio to a maximum size in MW.

    :param price_df: historical price data [operating_day, hour_beginning, node, da_price, rt_price]
    :param first_operating_day: first operating day for which to generate bids
    :param last_operating_day: last operating day for which to generate bids
    :return: data frame of bids [operating_day, hour_beginning, node, bid_type, bid_mw]
    """
    expected_spread = compute_expected_spread(price_df)
    spread_variance = compute_spread_variance(price_df)

    daily_expected_spread = get_daily_expected_spread_vectors(expected_spread)
    daily_spread_variance = get_daily_spread_variance_vectors(spread_variance)

    portfolios = []
    def minimize_portfolio(day):
        result = sp.optimize.minimize(
            portfolio_objective_fn,
            np.zeros(len(daily_expected_spread.columns)),
            args=(daily_expected_spread.loc[day].values, daily_spread_variance.loc[day].values,risk_tol),
            constraints={
                "type": "ineq",
                "fun": mw_constraint_fn,
                "args": [DAILY_VOLUME_LIMIT],
            },
        )
        return pd.DataFrame(
                result.x[None, :],
                columns=daily_expected_spread.columns,
                index=pd.Index([day], name="operating_day")
            )
    dates = pd.date_range(first_operating_day, last_operating_day)
    portfolios = Parallel(n_jobs=-1)(delayed(minimize_portfolio)(day) for day in tqdm.tqdm(dates))
    return get_bids_from_daily_portfolios(pd.concat(portfolios))


def risk_tuned_generate_daily_bids(
    price_df: pd.DataFrame,
    risk_tol:  t.Tuple,
    risk_tune_size: float,
    first_operating_day: t.Union[str, datetime.date],
    last_operating_day: t.Union[str, datetime.date],
) -> pd.DataFrame:
    """
    Generate bids for the date range, computing the expected DART spreads and estimated variances from
    the price data and limiting each daily portfolio to a maximum size in MW.

    :param price_df: historical price data [operating_day, hour_beginning, node, da_price, rt_price]
    :param first_operating_day: first operating day for which to generate bids
    :param last_operating_day: last operating day for which to generate bids
    :return: data frame of bids [operating_day, hour_beginning, node, bid_type, bid_mw]
    """
    best_risk = None
    best_pnl = -float('inf')

    dates = pd.date_range(first_operating_day, last_operating_day)
    last_operating_day = dates[int(len(dates)*risk_tune_size)]

    for risk in range(risk_tol[0],risk_tol[1],risk_tol[2]):
        bid_df = generate_daily_bids(price_df, risk, first_operating_day,last_operating_day)
        pnl = compute_total_pnl(price_df, bid_df)
        if pnl>best_pnl:
            best_pnl=pnl
            best_risk=risk
    
    print("Best risk tolerance:",best_risk)

    return generate_daily_bids(price_df, best_risk,first_operating_day,last_operating_day)


def load_price_data(path: str) -> pd.DataFrame:
    """
    Load historical price data

    :param path: path to a CSV of the price data
    :return: data frame of historical prices [operating_day, hour_beginning, node, da_price, rt_price]
    """
    return pd.read_csv(path, parse_dates=["operating_day"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--tune_risk_tol",type=bool, default=False)
    parser.add_argument("--risk_tol", help="risk tolerance, pass int a or range start end step)",nargs='+', type=int,default=[RISK_TOLERANCE])
    parser.add_argument("--risk_tune_size",type=float, help="ratio of data to use for tuning",default=0.2)

    args = parser.parse_args()

    price_df = load_price_data("prices.csv")
    print(f"Generating bids for 2022 with daily limit of 100 MW...")

    if args.tune_risk_tol:
        risk_rol_range = args.risk_tol
        risk_tune_size = args.risk_tune_size

        print("With Risk Tolerance tuning settings")
        print("Risk Tolerance range",risk_rol_range)
        print("Tuning size:",risk_tune_size)

        bid_df = risk_tuned_generate_daily_bids(price_df, risk_rol_range, risk_tune_size, "2022-01-01", "2022-12-31")
    else:
        risk_tol = args.risk_tol[0]
        print("With Risk Tolerance:",risk_tol)
        bid_df = generate_daily_bids(price_df, risk_tol, "2022-01-01", "2022-12-31")


    pnl = compute_total_pnl(price_df, bid_df)
    wlr = win_loss_rate(price_df, bid_df)
    pf = profit_factor(price_df, bid_df)
    # sr = sharpe_ratio(price_df, bid_df)

    bid_df.to_csv("bids.csv", index=False)
    print(f"The strategy made ${pnl:.2f}")
    print(f"The strategy had win/loss rate of {wlr:.2f}")
    print(f"The strategy had profit factor of {pf:.2f}")
    # print(f"The strategy has sharpe ratio of {sr:.2f}")

    # plot_drawdown(price_df, bid_df)
    plot_cummulative_returns(price_df, bid_df)
